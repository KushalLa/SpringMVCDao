package com.ems.dao;

import java.util.List;

import com.ems.bean.EmployeeBean;
import com.ems.exception.EmployeeException;

public interface IEmployeeDao {

	public int addEmployee(EmployeeBean bean) throws EmployeeException;
	
	public List<EmployeeBean> viewAllEmployees() throws EmployeeException;
}
